from django.contrib import admin

# Register your models here.
from .models import Users
@admin.register(Users)

class MemberAdmin (admin.ModelAdmin):
    list_display=['firstname','lastname','email','password']