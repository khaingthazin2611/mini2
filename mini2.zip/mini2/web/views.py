from django.shortcuts import render,redirect
from .models import Users
from django.http.response import HttpResponse
# Create your views here.

def index(request):
    if request.method == 'POST':
        member = Users(firstname=request.POST['firstname'], lastname=request.POST['lastname'],  email=request.POST['email'], password=request.POST['password'])
        member.save()
        return redirect('home')
    else:
        return render(request, 'web/index.html')

def login(request):
    return render(request, 'web/login.html')

def home(request):
    return HttpResponse('<h1>Welcome to our portal@_@</h1>')